CREATE TABLE blinkit_grocery (
    item_fat_content VARCHAR(50),
    item_identifier VARCHAR(20) PRIMARY KEY,
    item_type VARCHAR(100),
    outlet_establishment_year INT,
    outlet_identifier VARCHAR(20),
    outlet_location_type VARCHAR(50),
    outlet_size VARCHAR(20),
    outlet_type VARCHAR(50),
    item_visibility DECIMAL(10,6),
    item_weight DECIMAL(10,2),
    sales DECIMAL(10,4),
    rating DECIMAL(3,1)
);
LOAD DATA LOCAL INFILE 'C:/Users/Dell/Desktop/major_project_files/BlinkIT Grocery Data_csv.csv'
INTO TABLE blinkit_grocery
FIELDS TERMINATED BY ',' 
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;


